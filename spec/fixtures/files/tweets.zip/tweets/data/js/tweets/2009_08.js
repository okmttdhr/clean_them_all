Grailbird.data.tweets_2009_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3553187833",
  "text" : "\u9CE9\u5C71\u7531\u7D00\u592B\u306A\u3046",
  "id" : 3553187833,
  "created_at" : "2009-08-26 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3505458478",
  "text" : "\u982D\u304C\u30DC\u30B1\u30FC\u3068\u3059\u308B\u3002\u9593\u9055\u3044\u306A\u304F\u30E2\u30F3\u30CF\u30F3\u4E2D\u6BD2",
  "id" : 3505458478,
  "created_at" : "2009-08-24 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3509109036",
  "text" : "\u6975\u9650\u30EC\u30D9\u30EB\u306B\u7720\u3044",
  "id" : 3509109036,
  "created_at" : "2009-08-24 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3444028304",
  "text" : "\u4F1A\u793E\u3067\u307C\u3051\u30FC\u3063\u3068\u3057\u3066\u3044\u308B\u306A\u3046",
  "id" : 3444028304,
  "created_at" : "2009-08-21 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3444801300",
  "text" : "\u9A5A\u7570\u7684\u306B\u7720\u3044\n\u30E2\u30F3\u30CF\u30F3\u3092\u3084\u308A\u3059\u304E\u305F\u3093\u3060",
  "id" : 3444801300,
  "created_at" : "2009-08-21 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3422146764",
  "text" : "\u4F11\u307F\u30DC\u30B1\u3067\u529B\u304C\u3067\u306A\u3044",
  "id" : 3422146764,
  "created_at" : "2009-08-20 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
} ]