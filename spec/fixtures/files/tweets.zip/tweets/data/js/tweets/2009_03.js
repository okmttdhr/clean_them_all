Grailbird.data.tweets_2009_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1421386674",
  "text" : "JR\u9045\u308C\u3066\u308B\u30FC",
  "id" : 1421386674,
  "created_at" : "2009-03-31 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1398340403",
  "text" : "\u30E6\u30F3\u30B1\u30EB\u306E\u30B5\u30A4\u30C8\u304A\u3061\u3066\u308Bwww",
  "id" : 1398340403,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1399194792",
  "text" : "\u3057\u307E\u3063\u305F\u3001\u30E6\u30F3\u30B1\u30EB\u8CB7\u3046\u306E\u5FD8\u308C\u305Forz",
  "id" : 1399194792,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1399701864",
  "text" : "\u306A\u3093\u304B\u8ABF\u5B50\u3042\u304C\u3063\u3066\u304D\u305F\u30FC\u30FC\u30FC",
  "id" : 1399701864,
  "created_at" : "2009-03-27 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1391420413",
  "text" : "\u6625\u59EB\u3057\u307C\u3093\u306C\n\u5BD2\u3059\u304E\u30EF\u30ED\u30BF",
  "id" : 1391420413,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1391650049",
  "text" : "\u3061\u3087\u30FC\u6C17\u6301\u3061\u60AA\u308A\u3043\u3001\u3053\u308C\u306F\u65E9\u9000\u30EC\u30D9\u30EB\u3001\u6625\u59EB\u304B\u3080\u3070\u3063\u304F\uFF01\uFF01\uFF01",
  "id" : 1391650049,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1393029739",
  "text" : "\u65E5\u4ED8\u30D5\u30A9\u30FC\u30DE\u30C3\u30C8\u306BATOM\u578B\u306A\u3093\u3066\u3042\u308B\u306E\u304B\u30FC\ndate(DATE_ATOM)  \/\/ 2009-01-01T00:00:00+09:00\n\u3075\u3064\u30FC\u306E\u65E5\u4ED8\u3092\u51FA\u529B\u3057\u3066\u3066\u304A\u304B\u3057\u304F\u306A\u3063\u3066\u305F\u3063\u307D\u3044",
  "id" : 1393029739,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1393548759",
  "text" : "\u304A\u308F\u3063\u305F\u30FC\u3001\u304C\u3001\u7D42\u308F\u3089\u306A\u304B\u3063\u305F\u3001\u3001\u3001\n\u4F53\u304C\u91CD\u3044('A')",
  "id" : 1393548759,
  "created_at" : "2009-03-26 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1386882315",
  "text" : "\u4ECA\u65E5\u306F\u5BD2\u3044",
  "id" : 1386882315,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1387170938",
  "text" : "\u663C\u3054\u98EF\u98DF\u3046\u306E\u5FD8\u308C\u305Forz",
  "id" : 1387170938,
  "created_at" : "2009-03-25 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1378896279",
  "text" : "\u306A\u305C\u304B\u96FB\u8ECA\u304C\u8D85\u6E80\u54E1\n\u305D\u3057\u3066\u30B1\u30F3\u30AB\u3092\u306F\u3058\u3081\u308B\u304A\u3063\u3055\u3093\u3068\u306D\u30FC\u3061\u3083\u3093",
  "id" : 1378896279,
  "created_at" : "2009-03-24 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1372972226",
  "text" : "JR\u9045\u308C\u3066\u308B\u30FC",
  "id" : 1372972226,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1373099909",
  "text" : "\u96FB\u8ECA\u3053\u306D\u30FC\u30FC\u30FC",
  "id" : 1373099909,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1373268671",
  "text" : "\u3088\u3046\u3084\u304F\u4F1A\u793E\u306B\u7740\u3044\u305F\u30FB\u30FB\u30FB",
  "id" : 1373268671,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1374038616",
  "text" : "passive_record\u3063\u3066\u4FBF\u5229\u305D\u3046\u306A\u3093\u3060\u3051\u3069\u3001\u30B0\u30B0\u3063\u3066\u3082\u60C5\u5831\u5F15\u3063\u304B\u304B\u3089\u306A\u3044\u3068\u3053\u308D\u3092\u307F\u308B\u3068\u3042\u3093\u307E\u308A\u4F7F\u308F\u308C\u3066\u306A\u3044\u306E\u304B\u306D\u3047",
  "id" : 1374038616,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1374776521",
  "text" : "\u3082\u3046\u5E30\u308B\n\u5BD2\u3044\u3084",
  "id" : 1374776521,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1375409630",
  "text" : "Omni Graffle\u8CB7\u304A\u3046\u304B\u60A9\u3080\u30FC",
  "id" : 1375409630,
  "created_at" : "2009-03-23 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1365548989",
  "text" : "haml\u306F\u305F\u307E\u306B\u306F\u307E\u308B",
  "id" : 1365548989,
  "created_at" : "2009-03-21 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1351778308",
  "text" : "\u3046\u3080\u3001\u4ECA\u65E5\u3082\u671D\u304B\u3089\u4F53\u304C\u304A\u3082",
  "id" : 1351778308,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1351780681",
  "text" : "\u904B\u52D5\u4E0D\u8DB3\u304B\u306A\u30FC",
  "id" : 1351780681,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1352107949",
  "text" : "\u306A\u305C\u9867\u5BA2\u306F\u3053\u3046\u3082\u4E00\u753B\u9762\u306B\u6A5F\u80FD\u3092\u8A70\u3081\u8FBC\u307F\u305F\u304C\u308A\u3001\u305D\u3057\u3066\u305D\u306E\u3057\u308F\u5BC4\u305B\u3068\u3057\u3066\u306E\u8FF7\u8DEF\u306E\u3088\u3046\u306A\u51E6\u7406\u30D5\u30ED\u30FC\u3092\u53D7\u3051\u5165\u308C\u3089\u308C\u308B\u306E\u304B\u30FB\u30FB\u30FB",
  "id" : 1352107949,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1352348815",
  "text" : "haml\u306F\u3068\u304D\u3069\u304D\u306F\u307E\u308B\u30FB\u30FB\u30FB",
  "id" : 1352348815,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1353604044",
  "text" : "\u4ECA\u65E5\u306F\u4E00\u65E5\u4F53\u304C\u91CD\u304B\u3063\u305F\u305C\n\u305D\u3057\u3066\u5E30\u308A\u306B\u96E8('A')\n\u3001\u3001\u3001\u6625\u3060\u306A",
  "id" : 1353604044,
  "created_at" : "2009-03-19 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1347043307",
  "text" : "\u91D1\u571F\u65E5\u96E8\u307D\u3044\n\u3075\u3056\u3051\u3066\u308B\u306E\uFF1F",
  "id" : 1347043307,
  "created_at" : "2009-03-18 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1340869418",
  "text" : "\u3046\u30FC\u3080\u3001\u65E2\u5B58\u30A2\u30D7\u30EA\u3092rails 2.3\u306B\u30A2\u30D7\u30C7\u30B3\u3057\u305F\u3089script\/server\u3067\u843D\u3061\u308B\u308F\u3041\n\u3064\u30FC\u304B\u3001rails:update \u304C\u52B9\u3044\u3066\u306A\u3044\u3082\u3088\u308A\u30FB\u30FB\u30FB",
  "id" : 1340869418,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1341399586",
  "text" : "\u982D\u304C\u30DC\u30FC\u3068\u3059\u308B\n\u6625\u3060\u306A",
  "id" : 1341399586,
  "created_at" : "2009-03-17 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1326394108",
  "text" : "\u304A\u3063\u304D\u3057\u305F\u203C",
  "id" : 1326394108,
  "created_at" : "2009-03-14 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
} ]