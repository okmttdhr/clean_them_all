var user_details =  {
  "expanded_url" : "http:\/\/cohakim.com\/",
  "screen_name" : "cohakim",
  "location" : "Hyogo, Japan",
  "url" : "http:\/\/t.co\/HCRZcbAoiQ",
  "full_name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
  "bio" : "Web\u7CFB\u30D7\u30ED\u30B0\u30E9\u30DE\u3067\u3059\u3002\u30B5\u30FC\u30D3\u30B9\u3068\u304B\u30A2\u30D7\u30EA\u4F5C\u3063\u3066\u307E\u3059\u3002\u300C\u9ED2\u6B74\u53F2\u30AF\u30EA\u30FC\u30CA\u30FC\u300D\u304C\u4EE3\u8868\u4F5C\u3002\n\/rails\/\u30AE\u30FC\u30AF\u30CF\u30A6\u30B9\/\u5C71\u6B69\u304D\/7144\/\u30DE\u30AD\u30B7\u30D6\u30FC\u30B9\u30C8\/FF14\/\u30A2\u30CB\u30E1\/",
  "id" : "14186100",
  "created_at" : "2008-03-20 18:50:34 +0000",
  "display_url" : "cohakim.com"
}