Grailbird.data.tweets_2009_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1256114571",
  "text" : "\u96FB\u8ECA\u9045\u308C\u3066\u308B\u30FC\n\u96E8\u306E\u65E5\u306F\u3044\u3064\u3082\u3053\u308C\u3060\u3088",
  "id" : 1256114571,
  "created_at" : "2009-02-27 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1253104485",
  "text" : "iPhone\u5024\u4E0B\u3052\u304A\u3081",
  "id" : 1253104485,
  "created_at" : "2009-02-26 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1248704799",
  "text" : "safari4!!!",
  "id" : 1248704799,
  "created_at" : "2009-02-25 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1225895769",
  "text" : "CakePHP\u306EFilter\u3063\u3066\u30B5\u30D6\u30AF\u30E9\u30B9\u304B\u3089\u306E\u7D30\u304B\u3044\u5236\u5FA1\u304C\u3067\u304D\u306A\u3044\u306E\u306D\u30FB\u30FB\u30FB\n\u643A\u5E2F\u51FA\u529B\u7528\u6587\u5B57\u30B3\u30FC\u30C9\u5909\u63DB\u51E6\u7406\u3092\u30B9\u30AD\u30C3\u30D7\u3057\u305F\u3044\u3051\u3069\u3001\u4ED6\u793E\u304C\u4F5C\u3063\u305F\u30E2\u30B8\u30E5\u30FC\u30EB\u306A\u3093\u3067\u4FEE\u6B63\u3067\u304D\u306A\u3044\u3088\uFF3C(^o^)\uFF0F",
  "id" : 1225895769,
  "created_at" : "2009-02-19 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1226271333",
  "text" : "\u304A\u3063\u3055\u3093\u3068\u3042\u3070\u3055\u3093\u304C\u96FB\u8ECA\u5185\u3067\u5927\u3052\u3093\u304B",
  "id" : 1226271333,
  "created_at" : "2009-02-19 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1217758169",
  "text" : "\u8170\u304C\u75DB\u3044\u30FB\u30FB\u30FB\n\u4F1A\u793E\u306B\u307E\u3068\u3082\u306A\u30A4\u30B9\u3092\u6301\u3061\u8FBC\u3080\u65B9\u6CD5\u306F\u306A\u3044\u3082\u306E\u304B",
  "id" : 1217758169,
  "created_at" : "2009-02-17 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1213729266",
  "text" : "\u3084\u3070\u3044\u306C\n\u5909\u306A\u98A8\u90AA\u3072\u3044\u305F",
  "id" : 1213729266,
  "created_at" : "2009-02-16 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1206054791",
  "text" : "\u3093\uFF1F\u30A2\u30D1\u30C1\u306E\u9759\u7684\u30B3\u30F3\u30C6\u30F3\u30C4\u306E\u30AD\u30E3\u30C3\u30B7\u30E5\u3066\u306A\u306B\u3092\u30AD\u30E3\u30C3\u30B7\u30E5\u3059\u308B\uFF1F\u30ED\u30FC\u30AB\u30EB\u306B\u6301\u3064\u30AD\u30E3\u30C3\u30B7\u30E5\u304B\u306A\uFF1F\uFF1F\uFF1F",
  "id" : 1206054791,
  "created_at" : "2009-02-13 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1207874765",
  "text" : "Eclipse 3.4 + PDT 2.0 \u3067\u30D5\u30A1\u30A4\u30EB\u7DE8\u96C6\u4E2D\u306B\u5909\u306A\u30A8\u30E9\u30FC\u3067\u307E\u3059\u3088\u3063\u3068",
  "id" : 1207874765,
  "created_at" : "2009-02-13 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
} ]