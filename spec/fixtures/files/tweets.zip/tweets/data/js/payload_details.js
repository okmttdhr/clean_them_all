var payload_details =  {
  "tweets" : 24220,
  "created_at" : "2014-09-26 19:50:59 +0000",
  "lang" : "en"
}