Grailbird.data.tweets_2009_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2336866045",
  "text" : "\u304A\u306A\u304B\u3044\u305F\u3072\u30FB\u30FB\u30FB",
  "id" : 2336866045,
  "created_at" : "2009-06-26 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2217324152",
  "text" : "iPhone 3.0 \u304D\u3066\u308B\u30FB\u30FB\u30FB\u3069\u3046\u3057\u3088\u3046",
  "id" : 2217324152,
  "created_at" : "2009-06-18 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2189785358",
  "text" : "\u4F1A\u793E\u304B\u3089github\u3078\u306E\u63A5\u7D9A\u304C\u3057\u3087\u3063\u3061\u3085\u3046\u843D\u3061\u308B\u304A\u30FC",
  "id" : 2189785358,
  "created_at" : "2009-06-16 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2085736140",
  "text" : "Mac Mini \u30A2\u30C3\u30D7\u30C7\u30FC\u30C8\u3055\u308C\u306A\u3044\u304B\u306A\u30FC",
  "id" : 2085736140,
  "created_at" : "2009-06-09 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2086543352",
  "text" : "\u305F\u3079\u3059\u304E\u305F\u30FC\r\n\u306D\u3080\u3044",
  "id" : 2086543352,
  "created_at" : "2009-06-09 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2062678536",
  "text" : "\u4ECA\u8D77\u304D\u305F",
  "id" : 2062678536,
  "created_at" : "2009-06-07 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2056745163",
  "text" : "\u3044\u307E\n\u304A\u304D\u305F",
  "id" : 2056745163,
  "created_at" : "2009-06-06 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1998140307",
  "text" : "\u3042\u3001\u3001\u3001\u30C1\u30B1\u30C3\u30C8\u3001\u3001\u3001",
  "id" : 1998140307,
  "created_at" : "2009-06-02 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
} ]