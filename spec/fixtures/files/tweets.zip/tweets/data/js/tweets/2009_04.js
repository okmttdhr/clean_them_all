Grailbird.data.tweets_2009_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1634352064",
  "text" : "\u753B\u8CEA\u308F\u308B\u3044\u306A&gt;&lt;",
  "id" : 1634352064,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1639369457",
  "text" : "\u306A\u3093\u304B\u4F53\u8ABF\u308F\u308B\u30FC\uFF1E\uFF1C",
  "id" : 1639369457,
  "created_at" : "2009-04-28 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1616470863",
  "text" : "\u9A5A\u7570\u7684\u306A\u5BD2\u3055",
  "id" : 1616470863,
  "created_at" : "2009-04-25 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1590045986",
  "text" : "\u304F\u3055\u306A\u304Ewww",
  "id" : 1590045986,
  "created_at" : "2009-04-23 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1580166624",
  "text" : "\u3055\u3089\u3070\u3001Mac Office",
  "id" : 1580166624,
  "created_at" : "2009-04-22 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1563859970",
  "text" : "\u7B4B\u8089\u75DB\u304C1\u65E5\u9045\u308C\u3066\u304F\u308B\u3088\u3046\u306B\u306A\u3063\u305Forz",
  "id" : 1563859970,
  "created_at" : "2009-04-20 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1550939273",
  "text" : "\u81EA\u8EE2\u8ECA\u3067\u5439\u7530\u307E\u3067\u304D\u305F\u306E\u306F\u3044\u3044\u304C\u5E30\u308B\u306E\u304C\u3060\u308B\u3044\u3093\u3060\u3088\u306A\u3001\u3001\u3001",
  "id" : 1550939273,
  "created_at" : "2009-04-18 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1539322193",
  "text" : "\u4ECA\u65E5\u306F\u3061\u3087\u3063\u3068\u5BD2\u3044\u3084\u306D",
  "id" : 1539322193,
  "created_at" : "2009-04-17 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1514841421",
  "text" : "\u4E8B\u52D9\u6240\u6691\u3044\u3067\u3059\uFF65\uFF65\uFF65",
  "id" : 1514841421,
  "created_at" : "2009-04-14 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1507680063",
  "text" : "\u3053\u306E\u30B9\u30D1\u30B2\u30C1\u30FC\u306A\u30B7\u30B9\u30C6\u30E0\u306E\u30E1\u30F3\u30C6\u30CA\u30F3\u30B9\u3092\u983C\u307E\u308C\u308B\u305F\u3073\u306B\u5FC3\u304C\u5C11\u3057\u305A\u3064\u6B7B\u6EC5\u3057\u3066\u3044\u304F\u306E\u3092\u611F\u3058\u308B\u30FB\u30FB\u30FB",
  "id" : 1507680063,
  "created_at" : "2009-04-13 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1451009315",
  "text" : "\u30E6\u30F3\u30B1\u30EB\u7D50\u69CB\u52B9\u304F\u30FB\u30FB\u30FB",
  "id" : 1451009315,
  "created_at" : "2009-04-04 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1428409645",
  "text" : "\u4ECA\u65E5\u3082\u9045\u308C\u307E\u3057\u305F\n\u4EBA\u8EAB\u4E8B\u6545\u3068\u306F",
  "id" : 1428409645,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1428415815",
  "text" : "\u671D\u304B\u3089PC\u306E\u30EA\u30B9\u30C8\u30A2\u4F5C\u696D\n\u3060\u308B\u3044\u30FC",
  "id" : 1428415815,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1429948990",
  "text" : "\u5BD2\u3044\u304C\u306A",
  "id" : 1429948990,
  "created_at" : "2009-04-01 00:00:00 +0000",
  "user" : {
    "name" : "\u5B9A\u6642\u30C0\u30C3\u30B7\u30E5\u738Bcohakim",
    "screen_name" : "cohakim",
    "protected" : false,
    "id_str" : "14186100",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1715463485\/cohakim_normal.png",
    "id" : 14186100,
    "verified" : false
  }
} ]